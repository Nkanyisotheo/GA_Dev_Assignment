
package ga.assignment.q2;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.FileHandler;


public class GAAssignmentQ2 
{

    public static void main(String[] args)  throws IOException
    {
          FilHandler fh = new FilHandler();
          Student s = new Student();          
          List<Student>list=new ArrayList<Student>();
          fh.WriteResults(s, list);
          for(Student d:fh.getStudents(s))
          {
              System.out.println(d.lastname);
          }
    }
    
    
    
}


