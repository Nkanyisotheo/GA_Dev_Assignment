package ga.assignment;

import java.util.Random;

public class GAAssignment 
{
    public static void main(String[] args) 
    {        
        int[] array = new int[8];       
        SortArray(array);       
        
        int[] arr = {0,0,0,1,1,0};
        System.out.println("==Question 1.2==" +"\nFlip: " + result(arr));
    }
    
    
    //Question 1.1 (Sorting Array)
    public static void SortArray(int[] arr)
    {      
        Random r = new Random();
         for(int i=0;i<8;i++)
        {
            arr[i]=r.nextInt(99);           
        }
        int temp;
        for(int i=0;i<arr.length;i++)
        {
            for(int x=i+1;x<arr.length;x++)
            {
                if(arr[i] > arr[x])
                {
                    temp = arr[i];
                    arr[i] = arr[x];
                    arr[x] = temp;
                }
            }
        }
        
        System.out.println("==Question 1.1==");
        for(int x=0;x<arr.length-1;x++)
        {
            System.out.println(arr[x]);
        }
    }
    
    //Question 1.2 (Flipping coins)
    public static int result(int[] arr)
    {
        int heads=0, tails=0;
        int count=0;
        for(int i=0;i<arr.length;i++)
        {
            if(Integer.toString(arr[i]).length()>1)
            {
                String val=Integer.toString(arr[i]);
                for(int x=0;x<val.length();x++)
                {
                    if(val.charAt(x)=='1')
                    {                        
                       tails+=1;
                    }
                    else if(val.charAt(x)=='0')
                    {
                        heads+=1;
                    }
                }
            }
            
            if(arr[i]==1)
            {
                tails+=1;
            }
            else if(arr[i]==0)
            {
                heads+=1;
            }
        }
        
        if(heads>tails)
        {
            count = (heads/tails)-1;
        }
        else if(tails>heads){
            count = (tails/heads)-1;
        }
        
        return count;
    }
    
}
